# -*- coding: utf-8 -*-
{
    'name': "ECOSPHERE PARTNER",

    'summary': """
        """,

    'description': """
        Long description of module's purpose
    """,

    'author': "RATEFIARISON Sarobidy",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
        'contacts',
        ],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/contact_account_views.xml',
        'views/contact_category_views.xml',
        'views/contact_ecozone_views.xml',
        'views/contact_history_ecosphere_views.xml',
        'views/contact_individual_type_views.xml',
        'views/contact_project_type_views.xml',
        'views/contact_status_views.xml',
        'views/contact_type_price_views.xml',
        'views/individual_expertise_tags_views.xml',
        'views/interest_expressed_views.xml',
        'views/offer_propose_views.xml',
        'views/role_purchase_offer_partner_views.xml',
        'views/res_partner_inherit_views.xml',
        # 'data/contact_status_data.xml',
        # 'data/contact_account_data.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
}
