# -*- coding: utf-8 -*-

from . import contact_account
from . import contact_category
from . import contact_ecozone
from . import contact_history_ecosphere
from . import contact_individual_type
from . import contact_project_type
from . import contact_status
from . import contact_type_price
from . import individual_expertise_tags
from . import interest_expressed
from . import offer_propose
from . import res_partner_inherit
from . import role_purchase_offer_partner

