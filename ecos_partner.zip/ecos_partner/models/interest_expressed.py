# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class InterestExpressed(models.Model):
    _name = 'interest.expressed'
    _description = 'Interest express in'
    _rec_name = 'name'

    name = fields.Char('Interest express in')
    old_id = fields.Integer('Old ID')