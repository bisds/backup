# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class OfferPropose(models.Model):
    _name = 'offer.propose'
    _description = 'Offers proposed'
    _rec_name = 'name'

    name = fields.Char('Offer proposed')
    old_id = fields.Integer('Old ID')