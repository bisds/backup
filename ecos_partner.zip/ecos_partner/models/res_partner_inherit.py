# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ResPartnerInherit(models.Model):
    _inherit = 'res.partner'

    firstname = fields.Char(string="First name")
    surname = fields.Char(string="Surname")
    role_purchase_offer_partner_id = fields.Many2one('role.purchase.offer.partner', 
                                            string='Role towards the purchase of our offers')
    interest_expressed_ids = fields.Many2many('interest.expressed', string='Interest expressed in')
    individual_expertise_tags = fields.Many2many('individual.expertise.tags', string='Contact expertise tags')
    individual_type_tags = fields.Many2many('contact.individual.type', string='Partner type')
    individual_cellular_phone = fields.Char('Individual cellular phone')
    individual_phone = fields.Char('Individual phone')
    individual_second_mail = fields.Char('Individual second email')
    individual_linkedin_page = fields.Char('Contact Linkedin Page')
    # company_alt_phone = fields.Char('Company second phone')
    company_second_mail = fields.Char('Company second email')
    free_text = fields.Text('Enterprise offers')
    

    #fields for company
    company_category_id = fields.Many2one('contact.category', string='Company category')
    company_facebook_page = fields.Char('Company Facebook Page')
    company_insta_page = fields.Char('Company Instagram Page')
    company_youtube_page = fields.Char('Company Youtube Channel')
    company_tiktok_page = fields.Char('Company Tik Tok Page')
    company_linkedin_page = fields.Char('Company Linkedin Page')
    account_status_id = fields.Many2one('contact.status', string='Account contact status')
    ecozone_id = fields.Many2one('contact.ecozone', string="Eco zone")
    type_price_id = fields.Many2one('contact.type.price', string="Tarification type")
    category2_id = fields.Many2many('res.partner.industry', string="Organization type")
    history_tag = fields.Many2many('contact.history.ecosphere', string="History with ecosphere")
    propose_to_offer_tags = fields.Many2many('offer.propose', string="Offers proposed")
    account_type_id = fields.Many2many('contact.account', string="Account contact type")
    company_other_website = fields.Char('Company Other website')
    project_type_tags = fields.Many2many('contact.project.type', string='Project type')
    old_id = fields.Integer('Old id')

    def _default_state(self):
         return self.env['res.country.state'].search([('name', '=', 'Quebec')], limit=1).id

    state_id = fields.Many2one('res.country.state', default=_default_state)


class ResPartnerCategoryInherit(models.Model):
     _inherit = 'res.partner.category'
     
     old_id = fields.Integer('Old ID')


class ResPartnerIndustryInherit(models.Model):
     _inherit = 'res.partner.industry'
     
     old_id = fields.Integer('Old ID')


class ResPartnerTitleInherit(models.Model):
     _inherit = 'res.partner.title'
     
     old_id = fields.Integer('Old ID')