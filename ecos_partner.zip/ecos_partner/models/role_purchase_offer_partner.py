# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class RolePurchaseOfferPartner(models.Model):
    _name = 'role.purchase.offer.partner'
    _description = 'Role towards the purchase of our offers'
    _rec_name = 'name'

    name = fields.Char('Role towards the purchase of our offers')
    old_id = fields.Integer('Old ID')