# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactAccount(models.Model):
    _name = 'contact.account'
    _description = 'Account contact type'
    _rec_name = 'name'

    name = fields.Char('Account contact type')
    old_id = fields.Integer('Old ID')