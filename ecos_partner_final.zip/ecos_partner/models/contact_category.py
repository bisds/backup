# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactCategory(models.Model):
    _name = 'contact.category'
    _description = 'Company category'
    _rec_name = 'name'

    name = fields.Char('Company category')
    old_id = fields.Integer('Old ID')