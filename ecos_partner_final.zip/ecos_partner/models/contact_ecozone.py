# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactEcoZone(models.Model):
    _name = 'contact.ecozone'
    _description = 'Eco zone'
    _rec_name = 'name'

    name = fields.Char('Eco zone')
    old_id = fields.Integer('Old ID')