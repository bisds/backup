# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class contactHistoryEcosphere(models.Model):
    _name = 'contact.history.ecosphere'
    _description = 'History with ecosphere'
    _rec_name = 'name'

    name = fields.Char('History with ecosphere')
    old_id = fields.Integer('Old ID')