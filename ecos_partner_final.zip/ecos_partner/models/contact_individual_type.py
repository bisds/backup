# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactIndividualType(models.Model):
    _name = 'contact.individual.type'
    _description = 'Partner type'
    _rec_name = 'name'

    name = fields.Char('Contact individual type')
    old_id = fields.Integer('Old ID')