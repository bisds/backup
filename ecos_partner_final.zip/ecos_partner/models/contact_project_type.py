# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactProjectType(models.Model):
    _name = 'contact.project.type'
    _description = 'Project type'
    _rec_name = 'name'

    name = fields.Char('Project type')
    old_id = fields.Integer('Old ID')