# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactStatus(models.Model):
    _name = 'contact.status'
    _description = 'Account contact status'
    _rec_name = 'name'

    name = fields.Char('Account contact status')
    old_id = fields.Integer('Old ID')