# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class ContactTypePrice(models.Model):
    _name = 'contact.type.price'
    _description = 'Tarification type'
    _rec_name = 'name'

    name = fields.Char('Tarification type')
    old_id = fields.Integer('Old ID')