# -*- coding: utf-8 -*-

from odoo import _, api, fields, models


class IndividualExpertiseTags(models.Model):
    _name = 'individual.expertise.tags'
    _description = 'Individual expertise tags'
    _rec_name = 'name'

    name = fields.Char('Individual expertise tags')
    old_id = fields.Integer('Old ID')